## VPlayer

<img src="img/screenshot.jpg" width="666">

* <img src="http://i.imgur.com/a8vMYZ2.png" width="16" height="16"> The progress bar timestamp on mouse over and playback
* <img src="http://i.imgur.com/a8vMYZ2.png" width="16" height="16"> Toggle play/pause on button or video click
* <img src="http://i.imgur.com/a8vMYZ2.png" width="16" height="16"> The buffer bar with the loading progress of the video
* <img src="http://i.imgur.com/a8vMYZ2.png" width="16" height="16"> The progress bar with the play progress of the video
* <img src="http://i.imgur.com/a8vMYZ2.png" width="16" height="16"> Auto show/hide the controls when you hover on and off of the video
* <img src="http://i.imgur.com/a8vMYZ2.png" width="16" height="16"> Scrubbing by clicking and dragging on the progress bar
* <img src="http://i.imgur.com/a8vMYZ2.png" width="16" height="16"> Volume controls
* <img src="http://i.imgur.com/a8vMYZ2.png" width="16" height="16"> Full screen support (double-click video)
* <img src="http://i.imgur.com/a8vMYZ2.png" width="16" height="16"> Replay button at the end of the video
